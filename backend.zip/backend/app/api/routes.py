from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional
import uuid

from app.simulation.engine import sim_engine
from app.models.ev import EVModel, EVPriority, EVStatus
from app.models.station import StationOperatingStatus

from app.services.open_charge_map_provider import OpenChargeMapProvider
from app.models.open_charge_map_adapter import OpenChargeMapAdapter

router = APIRouter(prefix="/api")


class TickRequest(BaseModel):
    ticks: int = 1


class ResetRequest(BaseModel):
    seed: int = 42


class StrategyRequest(BaseModel):
    strategy: str = "FCFS_BASELINE"


class StationFaultRequest(BaseModel):
    station_id: str
    is_faulty: bool = True


# --- OPEN CHARGE MAP EXTERNAL DATA PROVIDER ENDPOINTS ---

@router.get("/openchargemap/status")
def get_open_charge_map_status():
    """Health check for Open Charge Map external API connection."""
    return OpenChargeMapProvider.check_open_charge_map_connection()


@router.get("/openchargemap/test")
def test_open_charge_map_connection():
    """Interactive Developer / Admin Test Endpoint for Open Charge Map API."""
    status = OpenChargeMapProvider.check_open_charge_map_connection()
    raw_response = OpenChargeMapProvider.fetch_raw_poi_data(country_code="IN", max_results=5)
    normalized_samples = OpenChargeMapAdapter.normalize_station_list(raw_response.get("data", []))
    
    return {
        "connection": "SUCCESS" if status.get("connected") else "FAILED",
        "http_status": status.get("statusCode"),
        "stations_retrieved": len(normalized_samples),
        "response_time_ms": status.get("responseTimeMs"),
        "last_tested": status.get("lastSync") or raw_response.get("lastSync"),
        "message": status.get("message") or raw_response.get("message"),
        "sample_stations": [s.dict() for s in normalized_samples[:3]]
    }


@router.get("/openchargemap/stations")
def get_open_charge_map_stations(
    country_code: str = "IN",
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    distance_km: Optional[float] = None,
    max_results: int = 25
):
    """
    Fetch and normalize real external charging stations from Open Charge Map.
    Supports location-based queries (lat/lng/distance) and country code.
    """
    raw = OpenChargeMapProvider.fetch_raw_poi_data(
        country_code=country_code,
        latitude=latitude,
        longitude=longitude,
        distance_km=distance_km,
        max_results=max_results
    )
    normalized = OpenChargeMapAdapter.normalize_station_list(raw.get("data", []))
    
    return {
        "source": raw.get("source", "OPEN_CHARGE_MAP"),
        "lastSync": raw.get("lastSync"),
        "station_count": len(normalized),
        "message": raw.get("message"),
        "stations": [s.dict() for s in normalized]
    }


@router.post("/openchargemap/sync")
def sync_open_charge_map_data(country_code: str = "IN", max_results: int = 25):
    """Trigger manual sync/refresh of Open Charge Map data and update simulation environment."""
    raw = OpenChargeMapProvider.fetch_raw_poi_data(country_code=country_code, max_results=max_results)
    normalized = OpenChargeMapAdapter.normalize_station_list(raw.get("data", []))
    
    # Merge external stations into simulation engine without breaking existing agents
    for ext_st in normalized:
        internal_dict = ext_st.to_internal_dict()
        st_id = internal_dict["id"]
        
        if st_id not in sim_engine.stations:
            from app.models.station import StationModel, StationOperatingStatus
            from app.models.charger import ChargerModel, ChargerType, ChargerStatus
            
            chargers = [
                ChargerModel(
                    id=f"{st_id}-CH-1",
                    stationId=st_id,
                    chargerType=ChargerType.ULTRA_FAST,
                    maximumPower=ext_st.chargingPowerKW,
                    currentStatus=ChargerStatus.AVAILABLE
                ),
                ChargerModel(
                    id=f"{st_id}-CH-2",
                    stationId=st_id,
                    chargerType=ChargerType.DC_FAST,
                    maximumPower=50.0,
                    currentStatus=ChargerStatus.AVAILABLE
                )
            ]
            
            new_station = StationModel(
                id=st_id,
                name=ext_st.stationName,
                location={"x": ext_st.longitude % 10.0, "y": ext_st.latitude % 10.0},
                numberOfChargers=len(chargers),
                chargingPower=ext_st.chargingPowerKW,
                energyPrice=0.25,
                operatingStatus=StationOperatingStatus.OPERATIONAL,
                chargers=chargers,
                dataSource="OPEN_CHARGE_MAP",
                availabilityMode="EXTERNAL_METADATA",
                operatorName=ext_st.operator,
                address=ext_st.address
            )
            sim_engine.stations[st_id] = new_station

    return {
        "sync_status": "COMPLETED",
        "source": raw.get("source"),
        "stations_synced": len(normalized),
        "total_active_stations": len(sim_engine.stations),
        "lastSync": raw.get("lastSync")
    }


# --- FULL SIMULATION STATE ---

@router.get("/state")
def get_state():
    from app.services.osm_provider import OSMProvider
    state = sim_engine.get_full_state()
    state["data_sources"] = {
        "openstreetmap": OSMProvider.check_osm_connection(),
        "open_charge_map": OpenChargeMapProvider.check_open_charge_map_connection(),
        "simulation_engine": {
            "status": "ACTIVE",
            "mode": "Classical AI Decision Engine",
            "data_honesty_notice": "OpenStreetMap & Open Charge Map provide real station metadata. Simulation engine generates dynamic charger occupancy state."
        }
    }
    return state


# --- EV ENDPOINTS ---

@router.get("/evs")
def list_evs(status: Optional[EVStatus] = Query(None)):
    ev_list = list(sim_engine.evs.values())
    if status:
        ev_list = [ev for ev in ev_list if ev.status == status]
    return [ev.model_dump() for ev in ev_list]


@router.get("/evs/{ev_id}")
def get_ev(ev_id: str):
    if ev_id not in sim_engine.evs:
        raise HTTPException(status_code=404, detail="EV not found")
    return sim_engine.evs[ev_id].model_dump()


@router.post("/evs", status_code=201)
def create_ev(ev: EVModel):
    sim_engine.add_or_update_ev(ev)
    return ev.model_dump()


@router.put("/evs/{ev_id}")
def update_ev(ev_id: str, ev: EVModel):
    if ev_id != ev.id:
        raise HTTPException(status_code=400, detail="EV ID in path does not match payload ID")
    sim_engine.add_or_update_ev(ev)
    return ev.model_dump()


# --- STATIONS & CHARGERS ENDPOINTS ---

@router.get("/stations")
def list_stations():
    return [st.model_dump() for st in sim_engine.stations.values()]


@router.get("/stations/{station_id}")
def get_station(station_id: str):
    if station_id not in sim_engine.stations:
        raise HTTPException(status_code=404, detail="Station not found")
    return sim_engine.stations[station_id].model_dump()


@router.get("/chargers")
def list_chargers(station_id: Optional[str] = Query(None)):
    chargers = list(sim_engine.chargers.values())
    if station_id:
        chargers = [c for c in chargers if c.stationId == station_id]
    return [c.model_dump() for c in chargers]


# --- GRID & ENERGY RESOURCES ENDPOINTS ---

@router.get("/grid")
def view_grid_status():
    return sim_engine.grid_node.model_dump()


@router.get("/resources")
def list_energy_resources():
    return [r.model_dump() for r in sim_engine.energy_resources.values()]


# --- AGENT ARCHITECTURE ENDPOINTS ---

@router.get("/agents")
def list_agents():
    from app.agents.message_broker import agent_broker
    return [agent.get_info() for agent in agent_broker.agents.values()]


@router.get("/agents/logs")
def list_agent_logs(limit: int = Query(100, ge=1, le=500)):
    from app.agents.message_broker import agent_broker
    return agent_broker.get_all_logs(limit)


@router.get("/agents/station-master/details")
def get_master_station_agent_details(station_id: Optional[str] = Query(None)):
    from app.agents.message_broker import agent_broker
    master_agent = agent_broker.get_agent("AGENT-STATION-MASTER")
    if not master_agent or not hasattr(master_agent, "get_station_details"):
        raise HTTPException(status_code=404, detail="Master Station Agent not active")
    return master_agent.get_station_details(station_id)


# --- KNOWLEDGE BASE & LOGICAL REASONING ENDPOINTS ---

@router.get("/kb/facts")
def list_kb_facts(subject: Optional[str] = Query(None)):
    from app.knowledge.kb import knowledge_base
    knowledge_base.sync_from_simulation(sim_engine)
    facts = knowledge_base.fact_base.list_facts(subject)
    return [f.model_dump() for f in facts]


@router.get("/kb/rules")
def list_kb_rules():
    from app.knowledge.kb import knowledge_base
    return [r.model_dump() for r in knowledge_base.rules]


@router.post("/kb/forward_chain")
def run_forward_chain():
    from app.knowledge.kb import knowledge_base
    res = knowledge_base.run_forward_chaining(sim_engine)
    return res.model_dump()


class PriorityQueryRequest(BaseModel):
    ev_id: str


class SafeChargingQueryRequest(BaseModel):
    ev_id: str
    station_id: str


@router.post("/kb/query/priority")
def query_priority(req: PriorityQueryRequest):
    from app.knowledge.kb import knowledge_base
    res = knowledge_base.query_why_priority(req.ev_id, sim_engine)
    return res.model_dump()


@router.post("/kb/query/safe_charging")
def query_safe_charging(req: SafeChargingQueryRequest):
    from app.knowledge.kb import knowledge_base
    res = knowledge_base.query_can_charge_safely(req.ev_id, req.station_id, sim_engine)
    return res.model_dump()


# --- SESSIONS ENDPOINTS ---

@router.get("/sessions")
def list_sessions():
    return [sess.model_dump() for sess in sim_engine.sessions.values()]


# --- SIMULATION CONTROL ENDPOINTS ---

@router.post("/tick")
def step_simulation(req: TickRequest):
    if req.ticks <= 0 or req.ticks > 1000:
        raise HTTPException(status_code=400, detail="Ticks must be between 1 and 1000")
    return sim_engine.step(req.ticks)


@router.post("/reset")
def reset_simulation(req: ResetRequest):
    sim_engine.reset_environment(req.seed)
    return sim_engine.get_full_state()


@router.post("/strategy")
def set_simulation_strategy(req: StrategyRequest):
    sim_engine.set_strategy(req.strategy)
    return sim_engine.get_full_state()


@router.post("/ev/add")
def add_custom_ev(ev: EVModel):
    sim_engine.add_or_update_ev(ev)
    sim_engine._apply_strategy()
    return sim_engine.get_full_state()


@router.post("/ev/emergency")
def inject_emergency_ev():
    ev_id = f"EV-EMERGENCY-{uuid.uuid4().hex[:4].upper()}"
    ev = EVModel(
        id=ev_id,
        batteryCapacity=100.0,
        currentBatteryLevel=5.0,
        requiredBatteryLevel=95.0,
        chargingRate=150.0,
        arrivalTime=sim_engine.current_tick_min,
        departureDeadline=sim_engine.current_tick_min + 30,
        priority=EVPriority.EMERGENCY,
        currentLocation={"x": 5.0, "y": 5.0},
        destination={"x": 2.5, "y": 8.0}
    )
    sim_engine.add_or_update_ev(ev)
    return sim_engine.get_full_state()


@router.post("/station/fault")
def toggle_station_fault(req: StationFaultRequest):
    if req.station_id not in sim_engine.stations:
        raise HTTPException(status_code=404, detail="Station not found")
    
    station = sim_engine.stations[req.station_id]
    if req.is_faulty:
        station.operatingStatus = StationOperatingStatus.FAULT
    else:
        station.operatingStatus = StationOperatingStatus.OPERATIONAL

    return sim_engine.get_full_state()


# --- PHASE 4: CLASSICAL AI SEARCH & ROUTE SELECTION ENDPOINTS ---

from app.search.station_selector import StationSelectorEngine, EVScenario
from app.search.graph import ChargingNetworkGraph

search_engine = StationSelectorEngine()


@router.get("/search/network")
def get_search_network():
    current_stations = [s.model_dump() for s in sim_engine.stations.values()]
    graph = ChargingNetworkGraph.create_default_network(stations=current_stations)
    return graph.to_dict()


@router.post("/search/compare-algorithms")
def compare_search_algorithms(scenario: EVScenario):
    current_stations = [s.model_dump() for s in sim_engine.stations.values()]
    engine = StationSelectorEngine()
    # We can pass scenario directly
    return engine.run_algorithm_comparison(scenario)


@router.post("/search/recommend-station")
def recommend_station(scenario: EVScenario):
    current_stations = [s.model_dump() for s in sim_engine.stations.values()]
    engine = StationSelectorEngine()
    return engine.compare_candidate_stations(scenario, stations_override=current_stations)


# --- PHASE 5: CONSTRAINT SATISFACTION BASED CHARGING SCHEDULER ENDPOINTS ---

class CSPSolveRequest(BaseModel):
    scenario_name: str = "NORMAL_DEMAND"
    enable_forward_checking: bool = True
    enable_ac3: bool = True
    enable_mrv: bool = True


@router.get("/csp/scenarios")
def list_csp_scenarios():
    return [
        {"id": "NORMAL_DEMAND", "name": "Normal Demand (Feasible Schedule)", "description": "Balanced grid and stations with available chargers and time windows."},
        {"id": "CHARGER_SHORTAGE", "name": "Charger Shortage", "description": "Multiple EVs competing for limited physical chargers; tests time-staggering."},
        {"id": "GRID_CAPACITY_SHORTAGE", "name": "Grid Capacity Shortage", "description": "Transformer capacity restricted to 100 kW; tests power allocation ceiling."},
        {"id": "DEADLINE_CONFLICTS", "name": "Deadline Conflicts", "description": "Tight departure deadlines arriving simultaneously."},
        {"id": "NO_FEASIBLE_SOLUTION", "name": "No Feasible Solution (Unfeasible)", "description": "Station outage and impossible deadlines triggering constraint violation diagnosis."}
    ]


@router.post("/csp/solve")
def solve_csp_schedule(req: CSPSolveRequest):
    from app.csp.scenarios import get_preset_csp_scenario
    from app.csp.solver import CSPSolver

    problem = get_preset_csp_scenario(req.scenario_name)
    solver = CSPSolver()
    result = solver.solve(
        problem=problem,
        enable_forward_checking=req.enable_forward_checking,
        enable_ac3=req.enable_ac3,
        enable_mrv=req.enable_mrv
    )
    return {
        "problem_state": problem.model_dump(),
        "solution": result.model_dump()
    }


# --- PHASE 6: MULTI-AGENT CONFLICT RESOLUTION ENDPOINTS ---

class NegotiationResolveRequest(BaseModel):
    scenario_id: str = "SCENARIO_IMMEDIATE_VS_OVERLOAD"


@router.get("/negotiation/scenarios")
def list_negotiation_scenarios():
    return [
        {
            "id": "SCENARIO_IMMEDIATE_VS_OVERLOAD",
            "name": "Immediate Charging vs Grid Transformer Overload (Benchmark Example)",
            "description": "EV demands immediate 150 kW fast charging, but Grid transformer capacity limit (300 kW) is threatened by current 200 kW load."
        },
        {
            "id": "SCENARIO_RENEWABLE_VS_WAIT",
            "name": "Renewable Solar Optimization vs EV Wait Time",
            "description": "Energy Agent advocates 45 min delay to utilize zero-carbon Solar generation, conflicting with EV desire for immediate departure."
        },
        {
            "id": "SCENARIO_STATION_QUEUE_VS_TRAVEL",
            "name": "Station Queue Clearance vs Extra Travel Distance",
            "description": "Station A has an 8-car queue causing 40 min wait delay; Station B has 0 queue but requires 4 km additional travel."
        }
    ]


@router.post("/negotiation/resolve")
def resolve_multi_agent_conflict(req: NegotiationResolveRequest):
    from app.game_theory.scenarios import get_preset_game_theory_scenario
    from app.game_theory.negotiation import NegotiationEngine

    sc_data = get_preset_game_theory_scenario(req.scenario_id)
    engine = NegotiationEngine()
    result = engine.resolve_conflict(
        scenario_name=sc_data["scenario_id"],
        custom_alternatives=sc_data["custom_alternatives"],
        grid_load_kw=sc_data["grid_load_kw"],
        transformer_limit_kw=sc_data["transformer_limit_kw"],
        ev_deadline_min=sc_data["ev_deadline_min"]
    )
    return result.model_dump()


# --- PHASE 7: DYNAMIC EV ECOSYSTEM SCENARIOS ENDPOINTS ---

class RunScenarioRequest(BaseModel):
    scenario_id: str = "SCENARIO_1_PEAK_SPIKE"
    seed: int = 42


@router.get("/scenarios/list")
def list_dynamic_scenarios():
    return [
        {
            "id": "SCENARIO_1_PEAK_SPIKE",
            "name": "Scenario 1 — Peak Demand Spike",
            "description": "Sudden arrival influx of 15 EVs simultaneously. Tests demand detection, CSP schedule regeneration, and grid overload prevention."
        },
        {
            "id": "SCENARIO_2_STATION_FAILURE",
            "name": "Scenario 2 — Charging Station Failure",
            "description": "Station CS-METRO shifts to FAULT status. Tests affected EV identification, A* search rerouting, and schedule regeneration."
        },
        {
            "id": "SCENARIO_3_GRID_OVERLOAD",
            "name": "Scenario 3 — Grid Overload Mitigation",
            "description": "Grid transformer limit restricted to 250 kW. Tests throttling non-critical sessions while preserving emergency EV priorities."
        },
        {
            "id": "SCENARIO_4_EMERGENCY_EV",
            "name": "Scenario 4 — Emergency EV Preemption",
            "description": "Emergency EV arrives with 5% battery and 30 min deadline. Tests Knowledge Base rule preemption and charging resource reallocation."
        },
        {
            "id": "SCENARIO_5_RENEWABLE_AVAILABILITY",
            "name": "Scenario 5 — Renewable Energy Optimization",
            "description": "Solar power generation surges to 120 kW. Tests renewable power preference and cost optimization."
        }
    ]


@router.post("/scenarios/run")
def run_dynamic_scenario(req: RunScenarioRequest):
    from app.scenarios.scenario_engine import DynamicScenarioEngine

    engine = DynamicScenarioEngine()
    result = engine.run_scenario(req.scenario_id, seed=req.seed)
    return result.model_dump()


# --- PHASE 8: FINAL SYSTEM EVALUATION & BENCHMARK ENDPOINT ---

@router.get("/evaluation/benchmark")
def get_evaluation_benchmark(seed: int = 42):
    from app.evaluation.benchmark import BenchmarkEvaluator

    evaluator = BenchmarkEvaluator()
    result = evaluator.run_comparative_benchmark(seed=seed)
    return result.model_dump()


# --- OPENSTREETMAP, NOMINATIM & OSRM ENDPOINTS ---

@router.get("/osm/status")
def get_osm_status():
    from app.services.osm_provider import OSMProvider
    return OSMProvider.check_osm_connection()


@router.get("/osm/search")
def search_osm_places(q: str = "", limit: int = 5):
    from app.services.osm_provider import OSMProvider
    return OSMProvider.search_places(query=q, limit=limit)


@router.get("/osm/reverse")
def reverse_geocode_osm(lat: float, lon: float):
    from app.services.osm_provider import OSMProvider
    return OSMProvider.reverse_geocode(lat=lat, lon=lon)


@router.get("/osm/route")
def get_osm_route(start_lat: float, start_lng: float, end_lat: float, end_lng: float):
    from app.services.osm_provider import OSMProvider
    return OSMProvider.get_driving_route(
        start_lat=start_lat, 
        start_lng=start_lng, 
        end_lat=end_lat, 
        end_lng=end_lng
    )


@router.get("/osm/pois")
def get_osm_pois(lat: float, lon: float, radius: int = 2500, category: str = "all"):
    from app.services.osm_provider import OSMProvider
    return OSMProvider.get_nearby_pois(
        lat=lat, 
        lon=lon, 
        radius_m=radius, 
        category=category
    )





