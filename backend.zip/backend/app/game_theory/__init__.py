"""
Multi-Agent Conflict Resolution and Game-Theoretic Decision Engine.
Implements 4 distinct agent utility functions (EV, Station, Grid, Energy),
Pareto efficiency filtering, Nash Bargaining Product maximization, and 7-step decision traces.
"""
